.. geoUmbriaSUIT documentation master file, created by
   sphinx-quickstart on Sun Feb 02 22:41:59 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.



Bibliography
=============

[1] Boggia A. et al. (2007): Il modello di monitoraggio software UmbriaSUIT 1.0, ARPA Umbria, Perugia. 

[2] Hwang C. L. and Yoon K. Multiple Objective Decision Making Methods and Applications, A State-of-the-Art Survey . Springer - Verlag, 1981.

[3] QGIS Development Team, 2013. QGIS Geographic Information System. Open Source Geospatial Foundation Project. http://qgis.osgeo.org 

[4] Salvatore Greco , Benedetto Matarazzo , Roman Slowinski , Jerzy Stefanowski, An Algorithm for Induction of Decision Rules Consistent with the Dominance Principle, Revised Papers from the Second International Conference on Rough Sets and Current Trends in Computing, p.304-313, October 16-19, 2000 

[5] Greco, S., Matarazzo, B., Słowiński, R.: Rough sets theory for multi-criteria decision analysis. European Journal of Operational Research, 129, 1 (2001) 1–47
		

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

. 